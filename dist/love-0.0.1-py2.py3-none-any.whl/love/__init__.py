"""
Package creation and management, using Love. 

So now you can say that your packages was made with Love.
"""

__version__ = '0.0.1'

from .love import main

if __name__ == '__name__':
    main()
